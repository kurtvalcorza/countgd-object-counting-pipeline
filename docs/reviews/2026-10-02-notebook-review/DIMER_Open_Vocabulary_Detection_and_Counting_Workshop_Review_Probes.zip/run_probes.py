"""Review probes for tutorials/DIMER_Open_Vocabulary_Detection_and_Counting_Workshop.ipynb (CNT review, 2026-10-02).

Usage:  python run_probes.py <repo root> [--out results.json]

Static probes read the notebook JSON. Direct-execution probes (D*) exec the notebook's own model-free cells
(controls, generator, sample manifest, detection and counting metrics) on CPU in a temporary directory; no model
is downloaded or run. A probe reports `open` when the reviewed defect is present and `clear` when it is not, so the
same script can be re-run on a fixed revision.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

NB_REL = "tutorials/DIMER_Open_Vocabulary_Detection_and_Counting_Workshop.ipynb"
EVIDENCE_REL = "docs/execution-evidence/2026-09-26/DIMER_Open_Vocabulary_Detection_and_Counting_Workshop.ipynb"
EVIDENCE_DATASET_SHA = "53b17b4c873dd9a3455149c419df13db27de94306585f273fc8837cdb48a7160"


def src(cell):
    s = cell.get("source", "")
    return "".join(s) if isinstance(s, list) else s


def load(root):
    nb = json.loads((root / NB_REL).read_text(encoding="utf-8"))
    return nb, [c for c in nb["cells"] if c["cell_type"] == "code"], [c for c in nb["cells"] if c["cell_type"] == "markdown"]


def by_id(nb, cid):
    return next((c for c in nb["cells"] if c.get("id") == cid), None)


def probe_static(root):
    nb, code, md = load(root)
    out = {}
    code_text = "\n".join(src(c) for c in code)
    md_text = "\n".join(src(c) for c in md)

    # P01 ST4: runtime fetch of DIMER repository source
    # DIMER source by URL anywhere, or any URL fetch outside carried modules (carried samples.py modules fetch
    # public sample data, which ST6 allows).
    fetches = [c.get("id") for c in code
               if "raw.githubusercontent.com/kurtvalcorza" in src(c)
               or (not str(c.get("id", "")).startswith("carried-")
                   and ("raw.githubusercontent.com" in src(c) or "urllib.request.urlopen" in src(c)))]
    out["P01_runtime_source_fetch"] = {"cells": fetches, "status": "open" if fetches else "clear"}

    # P02 BYOD controls read anywhere besides the controls cell
    controls = by_id(nb, "daa99d90")
    readers = [c.get("id") for c in code if c is not controls and re.search(r"\bUSE_BYOD\b|\bBYOD_ZIP_PATH\b", src(c))]
    out["P02_byod_controls_dead"] = {"cells_reading_byod_controls": readers, "status": "clear" if readers else "open"}

    # P03 Grounding DINO reload parity compares the reloaded pipeline with itself
    parity = by_id(nb, "06a56cd1")
    s = src(parity) if parity else ""
    tautology = "a=fresh_gd.predict_boxes" in s.replace(" ", "") and "b=fresh_gd.predict_boxes" in s.replace(" ", "")
    asserted = "raise" in s or "assert" in s
    out["P03_grounding_reload_parity"] = {"self_comparison": tautology, "fails_on_mismatch": asserted,
                                          "status": "open" if tautology or not asserted else "clear"}

    # P04 density/distractor diagnostics include CountGD and read the distractor ratio
    diag = by_id(nb, "5fb1218c")
    d = src(diag) if diag else ""
    includes_countgd = "countgd" in d.lower()
    reads_ratio = bool(re.search(r"distractor", d)) and ("groupby" in d and "distractor" in d.split("groupby", 1)[-1] or "corr" in d or "excess" in d)
    out["P04_density_distractor_diagnostic"] = {"includes_countgd": includes_countgd, "analyses_distractors": reads_ratio,
                                                "status": "clear" if includes_countgd and reads_ratio else "open"}

    # P05 a runnable controlled-change activity exists; the CountGD threshold grid is used
    grid_used = len(re.findall(r"COUNTGD_THRESHOLD_GRID", code_text)) > 1
    activity = [c.get("id") for c in code if re.search(r"^\s*RUN_ACTIVITY\s*=", src(c), re.M)]
    out["P05_controlled_change_activity"] = {"countgd_threshold_grid_used": grid_used, "activity_toggle_cells": activity,
                                             "status": "clear" if grid_used and activity else "open"}

    # P06 FULL adapted-detector result and new-scene results reach the export
    export = by_id(nb, "43953ffd")
    e = src(export) if export else ""
    out["P06_results_missing_from_export"] = {"full_grounding_test_exported": "full_grounding_test" in e,
                                              "new_scene_result_exported": "new_countgd_result" in e or "new_scene" in e,
                                              "status": "clear" if "full_grounding_test" in e and ("new_countgd_result" in e or "new_scene" in e) else "open"}

    # P07 completion summary carries headline results
    summ = by_id(nb, "491b58e6")
    ss = src(summ) if summ else ""
    has_results = any(k in ss for k in ("mae", "ap50", "headline", "cross_table"))
    out["P07_summary_without_results"] = {"summary_has_metrics": has_results, "status": "clear" if has_results else "open"}

    # P08 report bundle scoped to this run
    run_scoped = "RUN_STARTED" in e or "RUN_ID" in e
    out["P08_bundle_not_run_scoped"] = {"export_uses_make_archive_of_whole_dir": "make_archive" in e, "run_scoped": run_scoped,
                                        "status": "clear" if run_scoped else "open"}

    # P09 infrastructure labelling, collapsing and terminology
    collapsed = [c.get("id") for c in code if c.get("metadata", {}).get("cellView") == "form"]
    infra_titles = [c.get("id") for c in code if src(c).startswith("# @title Infrastructure")]
    typos = [t for t in ("Try it yourselfs",) if t in md_text]
    workshop_words = len(re.findall(r"\bworkshop\b", md_text, re.I))
    out["P09_infrastructure_and_terminology"] = {"collapsed_cells": len(collapsed), "infrastructure_titled": len(infra_titles),
                                                 "typos": typos, "md_mentions_of_workshop": workshop_words,
                                                 "troubleshooting_headings": len(re.findall(r"^#+ .*Troubleshooting", md_text, re.M)),
                                                 "status": "clear" if collapsed and infra_titles and not typos and len(re.findall(r"^#+ .*Troubleshooting", md_text, re.M)) == 1 else "open"}

    # P10 guided layer: what-to-notice notes, predictions, sample answers
    notice = len(re.findall(r"What to notice", md_text))
    predict = len(re.findall(r"Before you run|Predict", md_text))
    details = len(re.findall(r"<details>", md_text))
    out["P10_guided_layer"] = {"what_to_notice": notice, "prediction_prompts": predict, "details_blocks": details,
                               "status": "clear" if notice >= 5 and details >= 4 else "open"}

    # P11 runtime and download expectation stated before Run all
    opening = src(nb["cells"][0]) + src(nb["cells"][1])
    states_runtime = bool(re.search(r"\bGB\b", opening)) and bool(re.search(r"min", opening))
    out["P11_runtime_expectation"] = {"opening_states_download_and_time": states_runtime, "status": "clear" if states_runtime else "open"}

    # P12 metadata honesty
    dimer = nb["metadata"].get("dimer", {})
    out["P12_metadata"] = {k: dimer.get(k) for k in ("standalone", "candidate_gate", "release_status", "clean_runtime_evidence", "notebook_spec")}

    # P13 executed evidence vs this revision's code cells
    ev_path = root / EVIDENCE_REL
    if ev_path.is_file():
        ev = json.loads(ev_path.read_text(encoding="utf-8"))
        def strip(s):
            return "\n".join(line for line in s.split("\n") if not line.startswith("# @title")).strip()
        ev_code = [strip(src(c)) for c in ev["cells"] if c["cell_type"] == "code"]
        cur_code = [strip(src(c)) for c in code]
        out["P13_evidence_covers_revision"] = {"evidence_code_cells": len(ev_code), "current_code_cells": len(cur_code),
                                               "identical_ignoring_title": ev_code == cur_code,
                                               "evidence_sha256": hashlib.sha256(ev_path.read_bytes()).hexdigest()}
    return out


def probe_carrier_pins(root):
    """The pinned CountGD carrier blobs equal this repository's src at the reviewed revision."""
    nb, code, _ = load(root)
    text = "\n".join(src(c) for c in code)
    block = text.split("COUNTGD_SOURCE", 1)[1].split("}", 1)[0] if "COUNTGD_SOURCE" in text else ""
    pins = dict(re.findall(r'"([a-z_]+\.py)":\s*\("([0-9a-f]{40})",\s*\d+\)', block))
    try:
        tree = subprocess.run(["git", "-C", str(root), "ls-tree", "HEAD", "src/countgd_pipeline/"], capture_output=True, text=True, check=True).stdout
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)}
    head = {line.split("\t")[1].rsplit("/", 1)[1]: line.split()[2] for line in tree.splitlines()}
    countgd_pins = {k: v for k, v in pins.items() if k in head}
    return {"countgd_pins_found": len(countgd_pins), "all_equal_head": all(head[k] == v for k, v in countgd_pins.items())}


def probe_direct(root):
    """Exec model-free cells on CPU; check the dataset digest against the hosted run and metric sanity."""
    os.environ.setdefault("MPLBACKEND", "Agg")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd
    import torch
    from PIL import Image, ImageDraw, ImageOps

    nb, _code, _ = load(root)
    ns = {"np": np, "pd": pd, "torch": torch, "plt": plt, "Image": Image, "ImageDraw": ImageDraw, "ImageOps": ImageOps,
          "display": lambda *a, **k: None, "__name__": "__probe__"}
    ids = ["daa99d90", "d5aa425c", "843fb01b", "83fbdc46", "f5ee4325"]
    out = {}
    with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(open(os.devnull, "w")):
        cwd = os.getcwd()
        os.chdir(tmp)
        try:
            for cid in ids:
                exec(compile(src(by_id(nb, cid)), cid, "exec"), ns)
        finally:
            os.chdir(cwd)
    out["D01_dataset_sha256_matches_hosted_run"] = ns["dataset_manifest"]["dataset_sha256"] == EVIDENCE_DATASET_SHA
    recs = ns["test_records"]
    perfect = [[{"box": b, "label": l, "score": 0.9} for b, l in zip(ns["detection_reference"](r)["boxes"], ns["detection_reference"](r)["labels"])] for r in recs]
    out["D02_perfect_detections_ap"] = round(ns["common_ap"](perfect, recs)["ap"], 6)
    # compensating errors: right count, wrong objects (distractor boxes in place of targets)
    r = recs[0]
    k = min(r["target_count"], r["distractor_count"])
    wrong = r["distractor_boxes"][:k] + r["target_boxes"][k:]
    res = ns["evaluate_count_predictions"]([{"count": len(wrong), "boxes": wrong, "points": [[(b[0] + b[2]) / 2, (b[1] + b[3]) / 2] for b in wrong]}], [r])
    out["D03_compensating_error_example"] = {"mae": res["mae"], "box_f1": round(res["boxes"]["f1"], 4)}
    out["D04_test_targets_distractors"] = {"targets": sum(x["target_count"] for x in recs), "distractors": sum(x["distractor_count"] for x in recs)}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--out", default="results.json")
    a = ap.parse_args()
    root = Path(a.root).resolve()
    res = {"notebook": NB_REL, "revision": subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip(),
           "notebook_sha256": hashlib.sha256((root / NB_REL).read_bytes()).hexdigest(),
           "static": probe_static(root), "carrier_pins": probe_carrier_pins(root)}
    try:
        res["direct_cpu"] = probe_direct(root)
    except Exception as exc:  # noqa: BLE001
        res["direct_cpu"] = {"error": f"{type(exc).__name__}: {exc}"}
    res["open"] = sorted(k for k, v in res["static"].items() if isinstance(v, dict) and v.get("status") == "open")
    Path(a.out).write_text(json.dumps(res, indent=2), encoding="utf-8")
    print(json.dumps({"open": res["open"], "direct_cpu": res["direct_cpu"]}, indent=2))


if __name__ == "__main__":
    sys.exit(main())
