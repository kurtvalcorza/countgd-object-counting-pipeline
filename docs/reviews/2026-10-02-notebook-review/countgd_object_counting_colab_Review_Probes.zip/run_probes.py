"""Probes for the Notebook Review Framework v1 review of tutorials/countgd_object_counting_colab.ipynb (row 16).

Executes the committed notebook's own code cells (extracted verbatim from the reviewed blob) in one Python
namespace, CPU only, in the pinned build venv (torch 2.14.0, torchvision 0.29.0, transformers 4.57.6,
safetensors 0.8.0, numpy 2.5.3, scipy 1.18.1, huggingface-hub 0.36.2; pillow 11.3.0), with the install skipped
via DIMER_NOTEBOOK_CI_PREINSTALLED=1. The CountGD source checkpoint, converted safetensors, tokenizer files and
FSC-147 photographs are hard-linked from an existing local snapshot into <workdir>/weights (manifests are NOT
linked; the notebook writes them itself) and re-hashed by the notebook's own verify_snapshot.

Not a Colab run and not a full default Run all (the full CPU path is ~21 min on this host; the clean default
journey rests on the recorded Kaggle T4 run of the same blob).

Usage: python run_probes.py <worktree> <weights_src> <workdir> [static|loader|model]
"""
import hashlib
import io
import json
import os
import re
import sys
import time
import traceback
import zipfile
from pathlib import Path

WT, WSRC, WORK = (Path(a) for a in sys.argv[1:4])
PHASE = sys.argv[4] if len(sys.argv) > 4 else "all"
NB_PATH = WT / "tutorials" / "countgd_object_counting_colab.ipynb"
OUT = WORK / f"results_{PHASE}.json"
R = {"phase": PHASE, "probes": {}}


def save():
    OUT.write_text(json.dumps(R, indent=2, default=str), encoding="utf-8")


def record(name, **kw):
    R["probes"][name] = kw
    save()
    print("PROBE", name, json.dumps(kw, default=str)[:600], flush=True)


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
src = lambda i: "".join(cells[i]["source"])  # noqa: E731
CODE = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
MD = "\n".join(src(i) for i, c in enumerate(cells) if c["cell_type"] == "markdown")

# ------------------------------------------------------------------ static
if PHASE in ("static", "all"):
    emb = [i for i in CODE if cells[i].get("metadata", {}).get("dimer", {}).get("embedded_module")]
    record("P1_structure", n_cells=len(cells), code_cells=CODE, embedded_module_cells=emb,
           embedded_lines={i: src(i).count("\n") + 1 for i in emb},
           metadata_dimer=nb["metadata"].get("dimer"),
           any_cellview_form=any("cellView" in json.dumps(cells[i].get("metadata", {})) for i in CODE),
           any_collapsed=any("collapsed" in json.dumps(cells[i].get("metadata", {})) or "jupyter" in cells[i].get("metadata", {}) for i in CODE))
    alltext = MD + "\n".join(src(i) for i in CODE)
    record("P2_install", uses_uv=bool(re.search(r"\buv (venv|pip)\b", alltext)),
           pip_install_in_kernel="pip', 'install'" in src(3),
           restart_guard="Restart the runtime, then rerun from the top" in src(3),
           md_says_stops_with_restart="stops with a restart instruction" in MD)
    kw = {k: bool(re.search(k, MD, re.I)) for k in [
        r"how to use", r"roadmap", r"intended (learner|audience)|who (this|the notebook) is for", r"glossary",
        r"predict", r"expected result|what to notice|look for", r"checkpoint", r"sample answer|<details",
        r"troubleshoot", r"infrastructure", r"conclusion template|your conclusion", r"re-?run (cells|from)",
        r"restart"]}
    record("P3_guided_layer_keywords", **kw)
    # numbers quoted in prose vs. the recorded T4 run
    quoted = {n: (n in MD) for n in ["0.92", "3.50", "0.550", "epoch 3", "35, 51 and 35", "51 to 35", "1.58", "3.54", "kept epoch 2"]}
    record("P4_quoted_build_record_numbers", quoted=quoted,
           t4_record={"synthetic_test_mae": "7.417 -> 1.583", "fsc_mae": "4.542 -> 3.542", "kept_epoch": 2, "box_f1": "0.453 -> 0.546"},
           cpu_record={"synthetic_test_mae": "7.417 -> 0.917", "fsc_mae": "4.542 -> 3.500", "kept_epoch": 3, "box_f1": "0.453 -> 0.550"})
    record("P5_never_saw_claim", sentences=[s.strip()[:200] for s in re.split(r"(?<=[.;])\s", MD) if "never saw" in s],
           pretraining_overlap_statement=bool(re.search(r"pretrain|pre-train|Objects365|O365|GoldG", MD)))
    record("P6_spec_version", declared=nb["metadata"]["dimer"]["notebook_spec"], current="2.2")

if PHASE == "static":
    sys.exit(0)

# ------------------------------------------------------------------ execute the carried modules
os.chdir(WORK)
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
G = {"__name__": "__main__"}


def run_cell(i, edits=None):
    code = src(i)
    for old, new in (edits or {}).items():
        assert old in code, (i, old)
        code = code.replace(old, new)
    t0 = time.perf_counter()
    exec(compile(code, f"<cell {i}>", "exec"), G)
    return round(time.perf_counter() - t0, 1)


def run_cell_capture(i, edits=None):
    try:
        return {"ok": True, "seconds": run_cell(i, edits)}
    except BaseException as exc:  # noqa: BLE001
        tb = traceback.format_exc().splitlines()
        return {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:300]}", "where": [l for l in tb if "<cell" in l][-2:]}


boot = {i: run_cell_capture(i) for i in CODE[:9]}  # cell 3 (install skipped) + 8 module cells
record("P7_boot_modules", cells=boot, env={k: G[k].__version__ for k in ("torch", "transformers", "numpy")})

# ------------------------------------------------------------------ BYOD loader / refusal probes (no model)
from PIL import Image  # noqa: E402

def scene_jpeg(seed):
    s = G["synthetic_scene"](seed)
    b = io.BytesIO()
    s["image"].save(b, format="PNG")
    return s, b.getvalue()


def make_zip(path, rows, files, header="id,file,label,count,points,exemplars,boxes", extra=None):
    with zipfile.ZipFile(path, "w") as z:
        lines = [header] + rows
        z.writestr("labels.csv", "\n".join(lines) + "\n")
        for name, data in files.items():
            z.writestr(name, data)
        for name, data in (extra or {}).items():
            z.writestr(name, data)
    return path


BYOD = WORK / "byod"
BYOD.mkdir(exist_ok=True)
scenes_multi = [scene_jpeg(9000 + k) for k in range(8)]
_first = scenes_multi[0][0]["label"]
scenes, _seed = [], 9000
while len(scenes) < 8:  # eight scenes sharing one label (the stated BYOD minimum, one category)
    _s = G["synthetic_scene"](_seed)
    if _s["label"] == _first:
        scenes.append(scene_jpeg(_seed))
    _seed += 1


def csvq(v):
    return '"' + json.dumps(v).replace('"', '""') + '"'


def rows_for(kind):
    rows, files = [], {}
    for k, (s, data) in enumerate(scenes):
        name = f"img{k}.png"
        files[name] = data
        pts = [[(b[0] + b[2]) / 2, (b[1] + b[3]) / 2] for b in s["boxes"]]
        if kind == "boxes":
            rows.append(f"s{k},{name},{s['label']},{s['count']},,{csvq(s['exemplars'])},{csvq(s['boxes'])}")
        elif kind == "points":
            rows.append(f"s{k},{name},{s['label']},{s['count']},{csvq(pts)},{csvq(s['exemplars'])},")
        elif kind == "count_only":
            rows.append(f"s{k},{name},{s['label']},{s['count']},,,")
    return rows, files


def try_load(zpath, split=True):
    try:
        recs = G["load_byod_dataset"](zpath)
        out = {"loaded": len(recs)}
        man = G["validate_dataset"](recs)
        out.update({"validated": man["n_records"], "with_points": man["with_points"], "with_boxes": man["with_boxes"]})
        if split:
            sp = G["split_dataset"](recs, seed=42)
            out["split"] = {k: len(v) for k, v in sp.items()}
        return out
    except BaseException as exc:  # noqa: BLE001
        return {"error": f"{type(exc).__name__}: {str(exc)[:200]}"}


if PHASE in ("loader", "all", "model", "model2"):
    res = {}
    for kind in ("boxes", "points", "count_only"):
        rows, files = rows_for(kind)
        res[kind] = try_load(make_zip(BYOD / f"{kind}.zip", rows, files))
    _keep = scenes
    scenes = scenes_multi
    rows, files = rows_for("boxes")
    res["eight_images_multi_label"] = try_load(make_zip(BYOD / "multi.zip", rows, files))
    res["eight_images_multi_label"]["labels"] = sorted({s["label"] for s, _ in scenes_multi})
    scenes = _keep
    rows, files = rows_for("boxes")
    with zipfile.ZipFile(BYOD / "nolabels.zip", "w") as z:
        for n, d in files.items():
            z.writestr(n, d)
    res["missing_labels_csv"] = try_load(BYOD / "nolabels.zip")
    res["missing_column"] = try_load(make_zip(BYOD / "nocol.zip", [r.split(",", 3)[0] + "," + r.split(",", 3)[1] + "," + r.split(",", 3)[2] for r in rows], files, header="id,file,label"))
    res["file_missing_from_zip"] = try_load(make_zip(BYOD / "nofile.zip", rows, {k: v for k, v in files.items() if k != "img3.png"}))
    res["undecodable_image"] = try_load(make_zip(BYOD / "badimg.zip", rows, {**files, "img2.png": b"not an image"}))
    bad = list(rows)
    bad[1] = bad[1].replace(f",{scenes[1][0]['count']},", ",abc,", 1)
    res["non_integer_count"] = try_load(make_zip(BYOD / "badcount.zip", bad, files))
    bad = list(rows)
    bad[2] = bad[2].replace(f",{scenes[2][0]['count']},", f",{scenes[2][0]['count'] + 1},", 1)
    res["count_disagrees_with_boxes"] = try_load(make_zip(BYOD / "disagree.zip", bad, files))
    res["too_few_records_5"] = try_load(make_zip(BYOD / "five.zip", rows[:5], files))
    # basename collision: two different images with the same basename in different folders
    rows_c = [r.replace("img0.png", "a/x.png").replace("img1.png", "b/x.png") for r in rows]
    files_c = {("a/x.png" if k == "img0.png" else "b/x.png" if k == "img1.png" else k): v for k, v in files.items()}
    zc = make_zip(BYOD / "collide.zip", rows_c, files_c)
    try:
        recs = G["load_byod_dataset"](zc)
        res["subfolder_paths_in_file_column"] = {"loaded": len(recs), "a_equals_b_pixels": G["image_digest"](recs[0]["image"]) == G["image_digest"](recs[1]["image"])}
        try:
            G["split_dataset"](recs, seed=42)
            res["subfolder_paths_in_file_column"]["split"] = "ok"
        except BaseException as exc:  # noqa: BLE001
            res["subfolder_paths_in_file_column"]["split"] = f"{type(exc).__name__}: {exc}"
    except BaseException as exc:  # noqa: BLE001
        res["subfolder_paths_in_file_column"] = {"error": f"{type(exc).__name__}: {exc}"}
    rows_t = [r.replace("img0.png", "../evil.png") for r in rows]
    files_t = {("../evil.png" if k == "img0.png" else k): v for k, v in files.items()}
    res["dotdot_member"] = try_load(make_zip(BYOD / "dotdot.zip", rows_t, files_t))
    (BYOD / "data.tar").write_bytes(b"x")
    res["tar_path"] = try_load(BYOD / "data.tar")
    record("P8_byod_loader", **res)

    # USE_BYOD=True with an empty path outside Colab (cell 23 as written)
    r = run_cell_capture(CODE[10], {"USE_BYOD = False": "USE_BYOD = True"})
    record("P9_byod_empty_path_outside_colab", **r)

if PHASE == "loader":
    sys.exit(0)

# ------------------------------------------------------------------ second invocation (model2)
if PHASE == "model2":
    # (a) BYOD at a size that passes Section 4: 18 single-label scenes (the smallest one-label size whose
    # 0.3/0.2 split leaves >= 4 records in every split), points-only / count-only / boxes, cells 23 -> 27.
    scenes18, _seed = [], 9000
    while len(scenes18) < 18:
        _s = G["synthetic_scene"](_seed)
        if _s["label"] == _first:
            scenes18.append(scene_jpeg(_seed))
        _seed += 1
    sizes = {}
    for n in range(8, 19):
        try:
            recs = [{"id": f"s{k}", "image": s["image"], "label": s["label"], "count": s["count"], "boxes": s["boxes"], "exemplars": s["exemplars"]} for k, (s, _) in enumerate(scenes18[:n])]
            sp = G["split_dataset"](recs, seed=42)
            for part in sp.values():
                G["validate_dataset"](part)
            sizes[n] = "passes Section 4"
        except BaseException as exc:  # noqa: BLE001
            sizes[n] = f"{type(exc).__name__}: {str(exc)[:80]}"
    record("P16_byod_minimum_size_one_label", sizes=sizes)
    scenes = scenes18
    r21 = run_cell_capture(CODE[9])
    record("P17_cell21_load", **r21)
    for kind in ("points", "count_only", "boxes"):
        rows, files = rows_for(kind)
        z = str(make_zip(BYOD / f"{kind}18.zip", rows, files)).replace("\\", "/")
        r_a = run_cell_capture(CODE[10], {"USE_BYOD = False": "USE_BYOD = True", "BYOD_ZIP_PATH = ''": f"BYOD_ZIP_PATH = '{z}'"})
        split_sizes = {k: len(v) for k, v in (G.get("splits") or {}).items()}
        r_b = run_cell_capture(CODE[12]) if r_a["ok"] else {"skipped": "cell 23 failed"}
        fz = G.get("frozen_syn") or {}
        record(f"P18_byod18_{kind}_cells23_27", cell23=r_a, split=split_sizes, cell27=r_b,
               boxes_n=(fz.get("boxes") or {}).get("n"), loc_n=(fz.get("localisation") or {}).get("n"),
               test_n=len(G.get("test_records") or []), mae=fz.get("mae") if r_b.get("ok") else None)
        if kind == "count_only" and r_a["ok"]:
            # what Section 7 does with count-only records (the cell after the failed assert)
            r_c = run_cell_capture(CODE[13], {"EPOCHS = 4": "EPOCHS = 1"})
            record("P19_byod18_count_only_cell29", **r_c)
    # (b) re-run hazard, deterministic: a first adaptation that keeps a trained epoch (stand-in for a completed
    # default Section 7, whose kept epoch was 3 on CPU and 2 on the T4) -> re-run cell 29 with
    # TRAINABLE_LAYERS = 0 as the Optional experiments suggest -> cell 33's export + reload + parity assertion.
    G.update({"train_records": G["train_records"][:2], "val_records": G["val_records"][:2], "test_records": G["test_records"][:2]})
    pipe = G["pipe"]
    base = {n: p.detach().clone() for n, p in pipe.model.named_parameters() if n.startswith("transformer.decoder.layers.5.")}
    first = pipe.adapt(G["train_records"], None, epochs=1, lr=2e-4, trainable_layers=2, seed=0)
    moved = max(float((p.detach() - base[n]).abs().max()) for n, p in pipe.model.named_parameters() if n in base)
    r2 = run_cell_capture(CODE[13], {"EPOCHS = 4": "EPOCHS = 1", "TRAINABLE_LAYERS = 2": "TRAINABLE_LAYERS = 0"})
    still = max(float((p.detach() - base[n]).abs().max()) for n, p in pipe.model.named_parameters() if n in base)
    record("P20_rerun_cell29_tl0_after_trained_adapt", first_kept_epoch=first["best_epoch"], layer5_max_change_after_first=moved,
           second=r2, second_history=G["adapt_result"]["history"] if r2["ok"] else None,
           second_n_trainable=G["adapt_result"]["n_trainable"] if r2["ok"] else None, layer5_max_change_after_second=still)
    c33 = src(CODE[15])
    seg = c33[c33.index("artifact_dir = Path("):c33.index("write_provenance(")]
    try:
        exec(compile("import shutil" + chr(10) + seg, "<cell 33 export+reload>", "exec"), G)
        rr = {"ok": True}
    except BaseException as exc:  # noqa: BLE001
        rr = {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:300]}"}
    record("P21_cell33_export_reload_after_rerun", **rr, parity=G.get("parity"),
           artifact_tensors=len(G["artifact_manifest"]["tensors"]) if G.get("artifact_manifest") else None)
    print("DONE2", flush=True)
    sys.exit(0)

# ------------------------------------------------------------------ model-backed probes
r21 = run_cell_capture(CODE[9])
record("P10_cell21_stage_verify_load", **r21, device=str(G.get("pipe").device) if G.get("pipe") else None,
       fetched=G.get("fetched"), checkpoint_source=getattr(G.get("pipe"), "checkpoint_source", None))
r23 = run_cell_capture(CODE[10])
record("P11_cell23_default_data", **r23,
       splits=G.get("disjoint"), fsc_test=len(G.get("fsc_test") or []))
r25 = run_cell_capture(CODE[11])
record("P12_cell25_demo_three_modes", **r25,
       counts={m: e["count"] for m, e in (G.get("demo_frozen") or {}).items()}, gold=G["demo"]["count"] if "demo" in G else None,
       checks=G.get("checks"))
default_state = {k: G[k] for k in ("train_records", "val_records", "test_records", "splits", "dataset_manifests", "disjoint", "data_source", "fsc_test", "fsc_splits")}

# BYOD points-only and boxes zips through cell 23 + cell 27 on the FROZEN model (as the notebook would on a
# first BYOD run in a fresh kernel)
for kind in ("points", "boxes", "count_only"):
    z = str(BYOD / f"{kind}.zip").replace("\\", "/")
    r_a = run_cell_capture(CODE[10], {"USE_BYOD = False": "USE_BYOD = True", "BYOD_ZIP_PATH = ''": f"BYOD_ZIP_PATH = '{z}'"})
    split_sizes = {k: len(v) for k, v in (G.get("splits") or {}).items()}
    r_b = run_cell_capture(CODE[12])
    fz = G.get("frozen_syn") or {}
    record(f"P13_byod_{kind}_cells23_27", cell23=r_a, split=split_sizes, cell27=r_b,
           boxes_n=(fz.get("boxes") or {}).get("n"), loc_n=(fz.get("localisation") or {}).get("n"), test_n=len(G.get("test_records") or []),
           mae=fz.get("mae"))
G.update(default_state)

# Active-learning re-run hazard, through the notebook's own cells 29 and 33 on a reduced set (2 train / 1 val
# scenes, 1 epoch) so it fits the time cap: run cell 29 once (default TRAINABLE_LAYERS=2), then re-run cell 29
# with TRAINABLE_LAYERS = 0 as the Optional experiments suggest, then the export/reload part of cell 33.
small = {"train_records": G["train_records"][:2], "val_records": G["val_records"][:1], "test_records": G["test_records"][:2]}
G.update(small)
frozen_val = G["pipe"].evaluate(G["val_records"])["mae"]
c29_edit = {"EPOCHS = 4": "EPOCHS = 1"}
r1 = run_cell_capture(CODE[13], c29_edit)
h1 = G["adapt_result"]["history"] if r1["ok"] else None
r2 = run_cell_capture(CODE[13], {**c29_edit, "TRAINABLE_LAYERS = 2": "TRAINABLE_LAYERS = 0"})
h2 = G["adapt_result"]["history"] if r2["ok"] else None
record("P14_rerun_cell29_trainable_layers_0", true_frozen_val_mae=frozen_val, first_run=r1, first_history=h1, second_run=r2, second_history=h2,
       second_epoch0_is_frozen=(h2[0]["val"]["mae"] == frozen_val) if h2 else None,
       second_n_trainable=G["adapt_result"]["n_trainable"] if r2["ok"] else None)
# cell 33 export + reload part only (demo re-count and result writing need Section 8 globals)
c33 = src(CODE[15])
start = c33.index("artifact_dir = Path(")
end = c33.index("write_provenance(")
G["_c33"] = c33[start:end]
try:
    exec(compile("import shutil\n" + G["_c33"], "<cell 33 export+reload>", "exec"), G)
    rr = {"ok": True}
except BaseException as exc:  # noqa: BLE001
    rr = {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:300]}"}
record("P15_cell33_export_reload_after_rerun", **rr, parity=G.get("parity"),
       artifact_tensors=len(G["artifact_manifest"]["tensors"]) if G.get("artifact_manifest") else None)
print("DONE", flush=True)
